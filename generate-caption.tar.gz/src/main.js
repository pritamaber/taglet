// main.js — Appwrite Cloud Function
import { OpenAI } from "openai";

export default async ({ req, res, log }) => {
  try {
    // ✅ Step 1: Parse the incoming request body
    const { base64Image, mood, style, customMessage } = JSON.parse(
      req.body || "{}"
    );

    // ✅ Step 2: Basic validation
    if (!base64Image) {
      return res.json({
        caption: "",
        hashtags: "",
        error: "Base64 image is required.",
      });
    }

    // ✅ Step 3: Initialize OpenAI with your secret key
    const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

    // ✅ Step 4: Create the dynamic prompt with optional modifiers
    const messages = [
      {
        role: "user",
        content: [
          {
            type: "text",
            text: `You're a viral social media expert.

Generate a short, engaging caption and 10 hashtags for the image below.

Mood: ${mood || "any"}
Style: ${style || "default"}
Message: ${customMessage || "none"}

Keep it audience-friendly and clear.`,
          },
          {
            type: "image_url",
            image_url: {
              url: base64Image, // Base64 image goes here
            },
          },
        ],
      },
    ];

    // ✅ Step 5: Call GPT-4 Vision model
    const response = await openai.chat.completions.create({
      model: "gpt-4-turbo", // Vision-capable model
      messages,
      max_tokens: 500,
    });

    // ✅ Step 6: Extract and sanitize the response
    const content = response.choices[0]?.message?.content || "";
    const [rawCaption, hashtags] = content.split("Hashtags:");

    // ✅ Step 7: Clean caption prefix like "Caption:" or "caption -"
    const caption = rawCaption
      ?.replace(/^caption[:\-]?\s*/i, "") // removes any "Caption:" at start
      .trim();

    // ✅ Step 8: Send back cleaned result to client
    return res.json({
      caption: caption || "⚠️ No caption returned.",
      hashtags: hashtags?.trim() || "#captionpop #ai",
    });
  } catch (err) {
    log("❌ Error: " + err.message);
    return res.json({
      caption: "",
      hashtags: "",
      error: "AI generation failed. Please try again.",
    });
  }
};
